import os
import json
import glob
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
from googletrans import Translator
from gtts import gTTS
import pygame

# === Font Path Setup ===
FONT_PATH = "C:\\Prasath\\Major Project\\Code\\fonts"
DEFAULT_FONT = os.path.join(FONT_PATH, "NotoSans-Regular.ttf")

LANG_FONTS = {
    "Hindi": os.path.join(FONT_PATH, "NotoSansDevanagari-Regular.ttf"),
    "Tamil": os.path.join(FONT_PATH, "NotoSansTamil-Regular.ttf"),
    "Telugu": os.path.join(FONT_PATH, "NotoSansTelugu-Regular.ttf"),
    "Malayalam": os.path.join(FONT_PATH, "NotoSansMalayalam-Regular.ttf"),
    "Kannada": os.path.join(FONT_PATH, "NotoSansKannada-Regular.ttf"),
    "Bengali": os.path.join(FONT_PATH, "NotoSansBengali-Regular.ttf"),
    "Gujarati": os.path.join(FONT_PATH, "NotoSansGujarati-Regular.ttf"),
    "Marathi": os.path.join(FONT_PATH, "TiroDevanagariMarathi-Regular.ttf")
}

LANG_CODES = {
    "Hindi": "hi",
    "Tamil": "ta",
    "Telugu": "te",
    "Malayalam": "ml",
    "Kannada": "kn",
    "Bengali": "bn",
    "Gujarati": "gu",
    "Marathi": "mr"
}

# === Load model and tokenizer once ===
model_name = "HuggingFaceH4/zephyr-7b-alpha"
tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side="left")
model = AutoModelForCausalLM.from_pretrained(model_name, device_map="auto", torch_dtype=torch.float16)
translator = Translator()

# === JSON loader and prompt constructor ===
def load_json(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)

def create_prompt_from_json(data):
    info = data["info"]
    teams = info["teams"]
    players = info["players"]
    prompt = f"""
### Instruction:
Generate a cricket match summary based on the given details.

### Input:
Match Summary:
- Date: {info['dates'][0]}
- Venue: {info['venue']}, {info.get('city', '')}
- Teams: {teams[0]} vs {teams[1]}
- Match Type: {info['match_type']} International
- Toss: {info['toss']['winner']} won the toss and chose to {info['toss']['decision']}
- Outcome: {info['outcome']['winner']} won by {info['outcome']['by']['runs']} runs
- Player of the Match: {", ".join(info['player_of_match'])}

Key Players:
{teams[0]}: {", ".join(players[teams[0]][:4])}
{teams[1]}: {", ".join(players[teams[1]][:4])}

### Response:
""".strip()
    return prompt

# === Text generation ===
def generate_commentary(prompt):
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    output_ids = model.generate(
        **inputs,
        max_new_tokens=200,
        do_sample=True,
        temperature=0.8,
        top_p=0.9,
        top_k=40,
        repetition_penalty=1.2,
        no_repeat_ngram_size=3
    )
    return tokenizer.decode(output_ids[0], skip_special_tokens=True)

# === TTS Function ===
def text_to_speech(text, lang_code, output_path):
    try:
        tts = gTTS(text=text, lang=lang_code)
        tts.save(output_path)
        print(f"🔊 TTS audio saved: {output_path}")
    except Exception as e:
        print(f"⚠️ TTS generation failed for {lang_code}: {e}")

# === Translate, save text, and generate speech ===
def save_translations(base_text, base_filename, output_folder):
    for lang, code in LANG_CODES.items():
        try:
            translated = translator.translate(base_text, dest=code).text
            txt_filename = f"{base_filename}_{lang}.txt"
            txt_path = os.path.join(output_folder, txt_filename)
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write(translated)
            print(f"🌐 Translated to {lang} → {txt_filename}")

            # === Save as speech
            mp3_filename = f"{base_filename}_{lang}.mp3"
            mp3_path = os.path.join(output_folder, mp3_filename)
            text_to_speech(translated, code, mp3_path)

        except Exception as e:
            print(f"⚠️ Translation to {lang} failed: {e}")

# === Batch processor ===
def process_all_jsons(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    json_files = glob.glob(os.path.join(input_folder, "*.json"))

    for file_path in json_files:
        try:
            data = load_json(file_path)
            prompt = create_prompt_from_json(data)
            commentary = generate_commentary(prompt)

            base_filename = os.path.splitext(os.path.basename(file_path))[0]
            en_path = os.path.join(output_folder, f"{base_filename}_EN.txt")

            # Save English text and audio
            with open(en_path, "w", encoding="utf-8") as f:
                f.write(commentary)
            print(f"✅ English summary saved: {base_filename}_EN.txt")

            en_audio_path = os.path.join(output_folder, f"{base_filename}_EN.mp3")
            text_to_speech(commentary, "en", en_audio_path)

            # Translations + TTS
            save_translations(commentary, base_filename, output_folder)

        except Exception as e:
            print(f"❌ Failed to process {file_path}: {e}")

# === Entry point ===
if __name__ == "__main__":
    input_folder = "C:\\Prasath\\praveen\\Least json files"
    output_folder = "generated_commentaries"
    process_all_jsons(input_folder, output_folder)
